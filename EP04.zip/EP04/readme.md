# Food App

/*
 * App layout
 *   - Header
 *       - Logo
 *       - Nav Item
 *   - Body
 *       - search
 *       - Res-card-container
 *           -Card
 *               - Img
 *               - Name
 *               - Time
 *               - cusines
 *               - Price
 *               - Rating
 *
 *   - Footer
 *       - Links
 *       - Address
 *       - Copyright
 *
 */