const Footer = () => {
    return <div className="footer">
        <h2>This is a Footer</h2>
        
    </div>
}

export default Footer;