const Contact = () => {
    return <div>
        <h1>Contact us</h1>
    </div>
}

export default Contact;